package vos.dtos.customer;

import lombok.Getter;
import lombok.Setter;
import xin.vico.framework.copiers.Copiers;
import xin.vico.framework.copiers.inter.Copier;
import xin.vico.framework.dto.JacksonBaseDto;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by IntelliJ IDEA.
 * User: bin.yu
 * Date: ${DATE}
 * Time: ${TIME}
 */
@Setter
@Getter
public class ${NAME} extends JacksonBaseDto {
   


    public static ${NAME}  toModel(${NAME}  input, String... skip) {
        Copier<${NAME} , Customer> register = Copiers.createMapper(CustomerDto.class, Customer.class).skip(skip).register();
        return register.copy(input);
    }

    public static List<Customer> toModel(List<${NAME} > input, String... skip) {
        return input.stream().map(x -> toModel(x, skip)).collect(Collectors.toList());
    }

    public static ${NAME}  toDto(Customer input, String... skip) {
        Copier<Customer, ${NAME} > register = Copiers.createMapper(Customer.class, CustomerDto.class).skip(skip).register();
        return register.copy(input);
    }


    public static List<${NAME} > toDto(List<Customer> input, String... skip) {
        return input.stream().map(x -> toDto(x, skip)).collect(Collectors.toList());
    }


}
